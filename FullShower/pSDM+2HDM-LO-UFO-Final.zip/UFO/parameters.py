# This file was automatically created by FeynRules 2.3.41
# Mathematica version: 12.0.0 for Linux x86 (64-bit) (April 7, 2019)
# Date: Fri 23 Jul 2021 13:18:34


from object_library import all_parameters, Parameter


from function_library import complexconjugate, re, im, csc, sec, acsc, asec, cot

# This is a default parameter object representing 0.
ZERO = Parameter(name = 'ZERO',
                 nature = 'internal',
                 type = 'real',
                 value = '0.0',
                 texname = '0')

# User-defined parameters.
cabi = Parameter(name = 'cabi',
                 nature = 'external',
                 type = 'real',
                 value = 0.227736,
                 texname = '\\theta _c',
                 lhablock = 'CKMBLOCK',
                 lhacode = [ 1 ])

beta = Parameter(name = 'beta',
               nature = 'external',
               type = 'real',
               value = 1.270000,
               texname = '\\text{Beta}',
               lhablock = 'Higgs',
               lhacode = [ 1 ])

a1 = Parameter(name = 'a1',
               nature = 'external',
               type = 'real',
               value = 1.270000,
               texname = '\\text{Alpha}_1',
               lhablock = 'Higgs',
               lhacode = [ 2 ])

a2 = Parameter(name = 'a2',
               nature = 'external',
               type = 'real',
               value = 0.,
               texname = '\\text{Alpha}_2',
               lhablock = 'Higgs',
               lhacode = [ 3 ])

a3 = Parameter(name = 'a3',
               nature = 'external',
               type = 'real',
               value = 0.,
               texname = '\\text{Alpha}_3',
               lhablock = 'Higgs',
               lhacode = [ 4 ])

a4 = Parameter(name = 'a4',
               nature = 'external',
               type = 'real',
               value = 1.44,
               texname = '\\text{Alpha}_4',
               lhablock = 'Higgs',
               lhacode = [ 5 ])

a5 = Parameter(name = 'a5',
               nature = 'external',
               type = 'real',
               value = 1.45,
               texname = '\\text{Alpha}_5',
               lhablock = 'Higgs',
               lhacode = [ 6 ])

a6 = Parameter(name = 'a6',
               nature = 'external',
               type = 'real',
               value = 1.41,
               texname = '\\text{Alpha}_6',
               lhablock = 'Higgs',
               lhacode = [ 7 ])

l5I = Parameter(name = 'l5I',
                nature = 'external',
                type = 'real',
                value = -0.3,
                texname = '\\text{l5I}',
                lhablock = 'Higgs',
                lhacode = [ 8 ])

l6R = Parameter(name = 'l6R',
                nature = 'external',
                type = 'real',
                value = -0.4,
                texname = '\\text{l6R}',
                lhablock = 'Higgs',
                lhacode = [ 9 ])

l7R = Parameter(name = 'l7R',
                nature = 'external',
                type = 'real',
                value = -0.3,
                texname = '\\text{l7R}',
                lhablock = 'Higgs',
                lhacode = [ 10 ])

k3R = Parameter(name = 'k3R',
                nature = 'external',
                type = 'real',
                value = -0.38,
                texname = '\\text{k3R}',
                lhablock = 'Higgs',
                lhacode = [ 11 ])

m12R = Parameter(name = 'm12R',
                 nature = 'external',
                 type = 'real',
                 value = 3600,
                 texname = '\\text{m12R}',
                 lhablock = 'Higgs',
                 lhacode = [ 12 ])

mud = Parameter(name = 'mud',
                nature = 'external',
                type = 'real',
                value = -225,
                texname = '\\text{mud}',
                lhablock = 'Higgs',
                lhacode = [ 13 ])

Imrhott = Parameter(name = 'Imrhott',
                    nature = 'external',
                    type = 'real',
                    value = 0.001,
                    texname = '\\text{Imrhott}',
                    lhablock = 'Higgs',
                    lhacode = [ 14 ])

Rerhott = Parameter(name = 'Rerhott',
                    nature = 'external',
                    type = 'real',
                    value = 0.001,
                    texname = '\\text{Rerhott}',
                    lhablock = 'Higgs',
                    lhacode = [ 15 ])

Imrhobb = Parameter(name = 'Imrhobb',
                    nature = 'external',
                    type = 'real',
                    value = 0.0001,
                    texname = '\\text{Imrhobb}',
                    lhablock = 'Higgs',
                    lhacode = [ 16 ])

Rerhobb = Parameter(name = 'Rerhobb',
                    nature = 'external',
                    type = 'real',
                    value = 0.0001,
                    texname = '\\text{Rerhobb}',
                    lhablock = 'Higgs',
                    lhacode = [ 17 ])

Imrhoee = Parameter(name = 'Imrhoee',
                    nature = 'external',
                    type = 'real',
                    value = 1.e-6,
                    texname = '\\text{Imrhoee}',
                    lhablock = 'Higgs',
                    lhacode = [ 18 ])

Rerhoee = Parameter(name = 'Rerhoee',
                    nature = 'external',
                    type = 'real',
                    value = 1.e-6,
                    texname = '\\text{Rerhoee}',
                    lhablock = 'Higgs',
                    lhacode = [ 19 ])

aEWM1 = Parameter(name = 'aEWM1',
                  nature = 'external',
                  type = 'real',
                  value = 127.9,
                  texname = '\\text{aEWM1}',
                  lhablock = 'SMINPUTS',
                  lhacode = [ 1 ])

Gf = Parameter(name = 'Gf',
               nature = 'external',
               type = 'real',
               value = 0.000011663900000000002,
               texname = '\\text{Gf}',
               lhablock = 'SMINPUTS',
               lhacode = [ 2 ])

aS = Parameter(name = 'aS',
               nature = 'external',
               type = 'real',
               value = 0.118,
               texname = '\\text{aS}',
               lhablock = 'SMINPUTS',
               lhacode = [ 3 ])

ymdo = Parameter(name = 'ymdo',
                 nature = 'external',
                 type = 'real',
                 value = 0.00504,
                 texname = '\\text{ymdo}',
                 lhablock = 'YUKAWA',
                 lhacode = [ 1 ])

ymup = Parameter(name = 'ymup',
                 nature = 'external',
                 type = 'real',
                 value = 0.00255,
                 texname = '\\text{ymup}',
                 lhablock = 'YUKAWA',
                 lhacode = [ 2 ])

yms = Parameter(name = 'yms',
                nature = 'external',
                type = 'real',
                value = 0.101,
                texname = '\\text{yms}',
                lhablock = 'YUKAWA',
                lhacode = [ 3 ])

ymc = Parameter(name = 'ymc',
                nature = 'external',
                type = 'real',
                value = 1.27,
                texname = '\\text{ymc}',
                lhablock = 'YUKAWA',
                lhacode = [ 4 ])

ymb = Parameter(name = 'ymb',
                nature = 'external',
                type = 'real',
                value = 4.7,
                texname = '\\text{ymb}',
                lhablock = 'YUKAWA',
                lhacode = [ 5 ])

ymt = Parameter(name = 'ymt',
                nature = 'external',
                type = 'real',
                value = 172,
                texname = '\\text{ymt}',
                lhablock = 'YUKAWA',
                lhacode = [ 6 ])

yme = Parameter(name = 'yme',
                nature = 'external',
                type = 'real',
                value = 0.000511,
                texname = '\\text{yme}',
                lhablock = 'YUKAWA',
                lhacode = [ 11 ])

ymm = Parameter(name = 'ymm',
                nature = 'external',
                type = 'real',
                value = 0.10566,
                texname = '\\text{ymm}',
                lhablock = 'YUKAWA',
                lhacode = [ 13 ])

ymtau = Parameter(name = 'ymtau',
                  nature = 'external',
                  type = 'real',
                  value = 1.777,
                  texname = '\\text{ymtau}',
                  lhablock = 'YUKAWA',
                  lhacode = [ 15 ])

GDI1x1 = Parameter(name = 'GDI1x1',
                   nature = 'external',
                   type = 'real',
                   value = 0,
                   texname = '\\text{GDI1x1}',
                   lhablock = 'YukawaGDI',
                   lhacode = [ 1, 1 ])

GDI1x2 = Parameter(name = 'GDI1x2',
                   nature = 'external',
                   type = 'real',
                   value = 0,
                   texname = '\\text{GDI1x2}',
                   lhablock = 'YukawaGDI',
                   lhacode = [ 1, 2 ])

GDI1x3 = Parameter(name = 'GDI1x3',
                   nature = 'external',
                   type = 'real',
                   value = 0,
                   texname = '\\text{GDI1x3}',
                   lhablock = 'YukawaGDI',
                   lhacode = [ 1, 3 ])

GDI2x1 = Parameter(name = 'GDI2x1',
                   nature = 'external',
                   type = 'real',
                   value = 0,
                   texname = '\\text{GDI2x1}',
                   lhablock = 'YukawaGDI',
                   lhacode = [ 2, 1 ])

GDI2x2 = Parameter(name = 'GDI2x2',
                   nature = 'external',
                   type = 'real',
                   value = 0,
                   texname = '\\text{GDI2x2}',
                   lhablock = 'YukawaGDI',
                   lhacode = [ 2, 2 ])

GDI2x3 = Parameter(name = 'GDI2x3',
                   nature = 'external',
                   type = 'real',
                   value = 0,
                   texname = '\\text{GDI2x3}',
                   lhablock = 'YukawaGDI',
                   lhacode = [ 2, 3 ])

GDI3x1 = Parameter(name = 'GDI3x1',
                   nature = 'external',
                   type = 'real',
                   value = 0,
                   texname = '\\text{GDI3x1}',
                   lhablock = 'YukawaGDI',
                   lhacode = [ 3, 1 ])

GDI3x2 = Parameter(name = 'GDI3x2',
                   nature = 'external',
                   type = 'real',
                   value = 0,
                   texname = '\\text{GDI3x2}',
                   lhablock = 'YukawaGDI',
                   lhacode = [ 3, 2 ])

GDI3x3 = Parameter(name = 'GDI3x3',
                   nature = 'external',
                   type = 'real',
                   value = 0,
                   texname = '\\text{GDI3x3}',
                   lhablock = 'YukawaGDI',
                   lhacode = [ 3, 3 ])

GDR1x1 = Parameter(name = 'GDR1x1',
                   nature = 'external',
                   type = 'real',
                   value = 1,
                   texname = '\\text{GDR1x1}',
                   lhablock = 'YukawaGDR',
                   lhacode = [ 1, 1 ])

GDR1x2 = Parameter(name = 'GDR1x2',
                   nature = 'external',
                   type = 'real',
                   value = 0.01,
                   texname = '\\text{GDR1x2}',
                   lhablock = 'YukawaGDR',
                   lhacode = [ 1, 2 ])

GDR1x3 = Parameter(name = 'GDR1x3',
                   nature = 'external',
                   type = 'real',
                   value = 0.01,
                   texname = '\\text{GDR1x3}',
                   lhablock = 'YukawaGDR',
                   lhacode = [ 1, 3 ])

GDR2x1 = Parameter(name = 'GDR2x1',
                   nature = 'external',
                   type = 'real',
                   value = 0.01,
                   texname = '\\text{GDR2x1}',
                   lhablock = 'YukawaGDR',
                   lhacode = [ 2, 1 ])

GDR2x2 = Parameter(name = 'GDR2x2',
                   nature = 'external',
                   type = 'real',
                   value = 1,
                   texname = '\\text{GDR2x2}',
                   lhablock = 'YukawaGDR',
                   lhacode = [ 2, 2 ])

GDR2x3 = Parameter(name = 'GDR2x3',
                   nature = 'external',
                   type = 'real',
                   value = 0.01,
                   texname = '\\text{GDR2x3}',
                   lhablock = 'YukawaGDR',
                   lhacode = [ 2, 3 ])

GDR3x1 = Parameter(name = 'GDR3x1',
                   nature = 'external',
                   type = 'real',
                   value = 0.01,
                   texname = '\\text{GDR3x1}',
                   lhablock = 'YukawaGDR',
                   lhacode = [ 3, 1 ])

GDR3x2 = Parameter(name = 'GDR3x2',
                   nature = 'external',
                   type = 'real',
                   value = 0.01,
                   texname = '\\text{GDR3x2}',
                   lhablock = 'YukawaGDR',
                   lhacode = [ 3, 2 ])

GDR3x3 = Parameter(name = 'GDR3x3',
                   nature = 'external',
                   type = 'real',
                   value = 1,
                   texname = '\\text{GDR3x3}',
                   lhablock = 'YukawaGDR',
                   lhacode = [ 3, 3 ])

GLI1x1 = Parameter(name = 'GLI1x1',
                   nature = 'external',
                   type = 'real',
                   value = 0,
                   texname = '\\text{GLI1x1}',
                   lhablock = 'YukawaGLI',
                   lhacode = [ 1, 1 ])

GLI1x2 = Parameter(name = 'GLI1x2',
                   nature = 'external',
                   type = 'real',
                   value = 0,
                   texname = '\\text{GLI1x2}',
                   lhablock = 'YukawaGLI',
                   lhacode = [ 1, 2 ])

GLI1x3 = Parameter(name = 'GLI1x3',
                   nature = 'external',
                   type = 'real',
                   value = 0,
                   texname = '\\text{GLI1x3}',
                   lhablock = 'YukawaGLI',
                   lhacode = [ 1, 3 ])

GLI2x1 = Parameter(name = 'GLI2x1',
                   nature = 'external',
                   type = 'real',
                   value = 0,
                   texname = '\\text{GLI2x1}',
                   lhablock = 'YukawaGLI',
                   lhacode = [ 2, 1 ])

GLI2x2 = Parameter(name = 'GLI2x2',
                   nature = 'external',
                   type = 'real',
                   value = 0,
                   texname = '\\text{GLI2x2}',
                   lhablock = 'YukawaGLI',
                   lhacode = [ 2, 2 ])

GLI2x3 = Parameter(name = 'GLI2x3',
                   nature = 'external',
                   type = 'real',
                   value = 0,
                   texname = '\\text{GLI2x3}',
                   lhablock = 'YukawaGLI',
                   lhacode = [ 2, 3 ])

GLI3x1 = Parameter(name = 'GLI3x1',
                   nature = 'external',
                   type = 'real',
                   value = 0,
                   texname = '\\text{GLI3x1}',
                   lhablock = 'YukawaGLI',
                   lhacode = [ 3, 1 ])

GLI3x2 = Parameter(name = 'GLI3x2',
                   nature = 'external',
                   type = 'real',
                   value = 0,
                   texname = '\\text{GLI3x2}',
                   lhablock = 'YukawaGLI',
                   lhacode = [ 3, 2 ])

GLI3x3 = Parameter(name = 'GLI3x3',
                   nature = 'external',
                   type = 'real',
                   value = 0,
                   texname = '\\text{GLI3x3}',
                   lhablock = 'YukawaGLI',
                   lhacode = [ 3, 3 ])

GLR1x1 = Parameter(name = 'GLR1x1',
                   nature = 'external',
                   type = 'real',
                   value = 1,
                   texname = '\\text{GLR1x1}',
                   lhablock = 'YukawaGLR',
                   lhacode = [ 1, 1 ])

GLR1x2 = Parameter(name = 'GLR1x2',
                   nature = 'external',
                   type = 'real',
                   value = 0.01,
                   texname = '\\text{GLR1x2}',
                   lhablock = 'YukawaGLR',
                   lhacode = [ 1, 2 ])

GLR1x3 = Parameter(name = 'GLR1x3',
                   nature = 'external',
                   type = 'real',
                   value = 0.01,
                   texname = '\\text{GLR1x3}',
                   lhablock = 'YukawaGLR',
                   lhacode = [ 1, 3 ])

GLR2x1 = Parameter(name = 'GLR2x1',
                   nature = 'external',
                   type = 'real',
                   value = 0.01,
                   texname = '\\text{GLR2x1}',
                   lhablock = 'YukawaGLR',
                   lhacode = [ 2, 1 ])

GLR2x2 = Parameter(name = 'GLR2x2',
                   nature = 'external',
                   type = 'real',
                   value = 1,
                   texname = '\\text{GLR2x2}',
                   lhablock = 'YukawaGLR',
                   lhacode = [ 2, 2 ])

GLR2x3 = Parameter(name = 'GLR2x3',
                   nature = 'external',
                   type = 'real',
                   value = 0.01,
                   texname = '\\text{GLR2x3}',
                   lhablock = 'YukawaGLR',
                   lhacode = [ 2, 3 ])

GLR3x1 = Parameter(name = 'GLR3x1',
                   nature = 'external',
                   type = 'real',
                   value = 0.01,
                   texname = '\\text{GLR3x1}',
                   lhablock = 'YukawaGLR',
                   lhacode = [ 3, 1 ])

GLR3x2 = Parameter(name = 'GLR3x2',
                   nature = 'external',
                   type = 'real',
                   value = 0.01,
                   texname = '\\text{GLR3x2}',
                   lhablock = 'YukawaGLR',
                   lhacode = [ 3, 2 ])

GLR3x3 = Parameter(name = 'GLR3x3',
                   nature = 'external',
                   type = 'real',
                   value = 1,
                   texname = '\\text{GLR3x3}',
                   lhablock = 'YukawaGLR',
                   lhacode = [ 3, 3 ])

GUI1x1 = Parameter(name = 'GUI1x1',
                   nature = 'external',
                   type = 'real',
                   value = 0,
                   texname = '\\text{GUI1x1}',
                   lhablock = 'YukawaGUI',
                   lhacode = [ 1, 1 ])

GUI1x2 = Parameter(name = 'GUI1x2',
                   nature = 'external',
                   type = 'real',
                   value = 0,
                   texname = '\\text{GUI1x2}',
                   lhablock = 'YukawaGUI',
                   lhacode = [ 1, 2 ])

GUI1x3 = Parameter(name = 'GUI1x3',
                   nature = 'external',
                   type = 'real',
                   value = 0,
                   texname = '\\text{GUI1x3}',
                   lhablock = 'YukawaGUI',
                   lhacode = [ 1, 3 ])

GUI2x1 = Parameter(name = 'GUI2x1',
                   nature = 'external',
                   type = 'real',
                   value = 0,
                   texname = '\\text{GUI2x1}',
                   lhablock = 'YukawaGUI',
                   lhacode = [ 2, 1 ])

GUI2x2 = Parameter(name = 'GUI2x2',
                   nature = 'external',
                   type = 'real',
                   value = 0,
                   texname = '\\text{GUI2x2}',
                   lhablock = 'YukawaGUI',
                   lhacode = [ 2, 2 ])

GUI2x3 = Parameter(name = 'GUI2x3',
                   nature = 'external',
                   type = 'real',
                   value = 0,
                   texname = '\\text{GUI2x3}',
                   lhablock = 'YukawaGUI',
                   lhacode = [ 2, 3 ])

GUI3x1 = Parameter(name = 'GUI3x1',
                   nature = 'external',
                   type = 'real',
                   value = 0,
                   texname = '\\text{GUI3x1}',
                   lhablock = 'YukawaGUI',
                   lhacode = [ 3, 1 ])

GUI3x2 = Parameter(name = 'GUI3x2',
                   nature = 'external',
                   type = 'real',
                   value = 0,
                   texname = '\\text{GUI3x2}',
                   lhablock = 'YukawaGUI',
                   lhacode = [ 3, 2 ])

GUI3x3 = Parameter(name = 'GUI3x3',
                   nature = 'external',
                   type = 'real',
                   value = 0,
                   texname = '\\text{GUI3x3}',
                   lhablock = 'YukawaGUI',
                   lhacode = [ 3, 3 ])

GUR1x1 = Parameter(name = 'GUR1x1',
                   nature = 'external',
                   type = 'real',
                   value = 1,
                   texname = '\\text{GUR1x1}',
                   lhablock = 'YukawaGUR',
                   lhacode = [ 1, 1 ])

GUR1x2 = Parameter(name = 'GUR1x2',
                   nature = 'external',
                   type = 'real',
                   value = 0.01,
                   texname = '\\text{GUR1x2}',
                   lhablock = 'YukawaGUR',
                   lhacode = [ 1, 2 ])

GUR1x3 = Parameter(name = 'GUR1x3',
                   nature = 'external',
                   type = 'real',
                   value = 0.01,
                   texname = '\\text{GUR1x3}',
                   lhablock = 'YukawaGUR',
                   lhacode = [ 1, 3 ])

GUR2x1 = Parameter(name = 'GUR2x1',
                   nature = 'external',
                   type = 'real',
                   value = 0.01,
                   texname = '\\text{GUR2x1}',
                   lhablock = 'YukawaGUR',
                   lhacode = [ 2, 1 ])

GUR2x2 = Parameter(name = 'GUR2x2',
                   nature = 'external',
                   type = 'real',
                   value = 1,
                   texname = '\\text{GUR2x2}',
                   lhablock = 'YukawaGUR',
                   lhacode = [ 2, 2 ])

GUR2x3 = Parameter(name = 'GUR2x3',
                   nature = 'external',
                   type = 'real',
                   value = 0.01,
                   texname = '\\text{GUR2x3}',
                   lhablock = 'YukawaGUR',
                   lhacode = [ 2, 3 ])

GUR3x1 = Parameter(name = 'GUR3x1',
                   nature = 'external',
                   type = 'real',
                   value = 0.01,
                   texname = '\\text{GUR3x1}',
                   lhablock = 'YukawaGUR',
                   lhacode = [ 3, 1 ])

GUR3x2 = Parameter(name = 'GUR3x2',
                   nature = 'external',
                   type = 'real',
                   value = 0.01,
                   texname = '\\text{GUR3x2}',
                   lhablock = 'YukawaGUR',
                   lhacode = [ 3, 2 ])

GUR3x3 = Parameter(name = 'GUR3x3',
                   nature = 'external',
                   type = 'real',
                   value = 1,
                   texname = '\\text{GUR3x3}',
                   lhablock = 'YukawaGUR',
                   lhacode = [ 3, 3 ])

tbeta = Parameter(name = 'tbeta',
                  nature = 'internal',
                  type = 'real',
                  value = 'cmath.tan(beta)',
                  texname = '\\text{tbeta}',
                  lhablock = 'FRBlock',
                  lhacode = [ 1 ])

vs = Parameter(name = 'vs',
               nature = 'external',
               type = 'real',
               value = 730,
               texname = '\\text{vs}',
               lhablock = 'FRBlock',
               lhacode = [ 2 ])

MZ = Parameter(name = 'MZ',
               nature = 'external',
               type = 'real',
               value = 91.1876,
               texname = '\\text{MZ}',
               lhablock = 'MASS',
               lhacode = [ 23 ])

Me = Parameter(name = 'Me',
               nature = 'external',
               type = 'real',
               value = 0.000511,
               texname = '\\text{Me}',
               lhablock = 'MASS',
               lhacode = [ 11 ])

MMU = Parameter(name = 'MMU',
                nature = 'external',
                type = 'real',
                value = 0.10566,
                texname = '\\text{MMU}',
                lhablock = 'MASS',
                lhacode = [ 13 ])

MTA = Parameter(name = 'MTA',
                nature = 'external',
                type = 'real',
                value = 1.777,
                texname = '\\text{MTA}',
                lhablock = 'MASS',
                lhacode = [ 15 ])

MU = Parameter(name = 'MU',
               nature = 'external',
               type = 'real',
               value = 0.00255,
               texname = 'M',
               lhablock = 'MASS',
               lhacode = [ 2 ])

MC = Parameter(name = 'MC',
               nature = 'external',
               type = 'real',
               value = 1.27,
               texname = '\\text{MC}',
               lhablock = 'MASS',
               lhacode = [ 4 ])

MT = Parameter(name = 'MT',
               nature = 'external',
               type = 'real',
               value = 172,
               texname = '\\text{MT}',
               lhablock = 'MASS',
               lhacode = [ 6 ])

MD = Parameter(name = 'MD',
               nature = 'external',
               type = 'real',
               value = 0.00504,
               texname = '\\text{MD}',
               lhablock = 'MASS',
               lhacode = [ 1 ])

MS = Parameter(name = 'MS',
               nature = 'external',
               type = 'real',
               value = 0.101,
               texname = '\\text{MS}',
               lhablock = 'MASS',
               lhacode = [ 3 ])

MB = Parameter(name = 'MB',
               nature = 'external',
               type = 'real',
               value = 4.7,
               texname = '\\text{MB}',
               lhablock = 'MASS',
               lhacode = [ 5 ])

mh1 = Parameter(name = 'mh1',
                nature = 'external',
                type = 'real',
                value = 125.24,
                texname = '\\text{mh1}',
                lhablock = 'MASS',
                lhacode = [ 25 ])

mh2 = Parameter(name = 'mh2',
                nature = 'external',
                type = 'real',
                value = 310,
                texname = '\\text{mh2}',
                lhablock = 'MASS',
                lhacode = [ 35 ])

mh3 = Parameter(name = 'mh3',
                nature = 'external',
                type = 'real',
                value = 340,
                texname = '\\text{mh3}',
                lhablock = 'MASS',
                lhacode = [ 36 ])

mh4 = Parameter(name = 'mh4',
                nature = 'external',
                type = 'real',
                value = 400,
                texname = '\\text{mh4}',
                lhablock = 'MASS',
                lhacode = [ 38 ])

mhc = Parameter(name = 'mhc',
                nature = 'external',
                type = 'real',
                value = 500,
                texname = '\\text{mhc}',
                lhablock = 'MASS',
                lhacode = [ 37 ])

ma = Parameter(name = 'ma',
               nature = 'external',
               type = 'real',
               value = 30.,
               texname = '\\text{ma}',
               lhablock = 'MASS',
               lhacode = [ 52 ])

WZ = Parameter(name = 'WZ',
               nature = 'external',
               type = 'real',
               value = 2.4952,
               texname = '\\text{WZ}',
               lhablock = 'DECAY',
               lhacode = [ 23 ])

WW = Parameter(name = 'WW',
               nature = 'external',
               type = 'real',
               value = 2.085,
               texname = '\\text{WW}',
               lhablock = 'DECAY',
               lhacode = [ 24 ])

WT = Parameter(name = 'WT',
               nature = 'external',
               type = 'real',
               value = 1.50833649,
               texname = '\\text{WT}',
               lhablock = 'DECAY',
               lhacode = [ 6 ])

Wh1 = Parameter(name = 'Wh1',
                nature = 'external',
                type = 'real',
                value = 0.00606148,
                texname = '\\text{Wh1}',
                lhablock = 'DECAY',
                lhacode = [ 25 ])

Wh2 = Parameter(name = 'Wh2',
                nature = 'external',
                type = 'real',
                value = 0.53896,
                texname = '\\text{Wh2}',
                lhablock = 'DECAY',
                lhacode = [ 35 ])

Wh3 = Parameter(name = 'Wh3',
                nature = 'external',
                type = 'real',
                value = 0.108117,
                texname = '\\text{Wh3}',
                lhablock = 'DECAY',
                lhacode = [ 36 ])

Wh4 = Parameter(name = 'Wh4',
                nature = 'external',
                type = 'real',
                value = 0.713633,
                texname = '\\text{Wh4}',
                lhablock = 'DECAY',
                lhacode = [ 38 ])

Whc = Parameter(name = 'Whc',
                nature = 'external',
                type = 'real',
                value = 8.19422,
                texname = '\\text{Whc}',
                lhablock = 'DECAY',
                lhacode = [ 37 ])

aEW = Parameter(name = 'aEW',
                nature = 'internal',
                type = 'real',
                value = '1/aEWM1',
                texname = '\\text{aEW}')

G = Parameter(name = 'G',
              nature = 'internal',
              type = 'real',
              value = '2*cmath.sqrt(aS)*cmath.sqrt(cmath.pi)',
              texname = 'G')

cbeta = Parameter(name = 'cbeta',
                  nature = 'internal',
                  type = 'real',
                  value = 'cmath.cos(beta)',
                  texname = '\\text{cbeta}')

CKM1x1 = Parameter(name = 'CKM1x1',
                   nature = 'internal',
                   type = 'complex',
                   value = 'cmath.cos(cabi)',
                   texname = '\\text{CKM1x1}')

CKM1x2 = Parameter(name = 'CKM1x2',
                   nature = 'internal',
                   type = 'complex',
                   value = 'cmath.sin(cabi)',
                   texname = '\\text{CKM1x2}')

CKM1x3 = Parameter(name = 'CKM1x3',
                   nature = 'internal',
                   type = 'complex',
                   value = '0',
                   texname = '\\text{CKM1x3}')

CKM2x1 = Parameter(name = 'CKM2x1',
                   nature = 'internal',
                   type = 'complex',
                   value = '-cmath.sin(cabi)',
                   texname = '\\text{CKM2x1}')

CKM2x2 = Parameter(name = 'CKM2x2',
                   nature = 'internal',
                   type = 'complex',
                   value = 'cmath.cos(cabi)',
                   texname = '\\text{CKM2x2}')

CKM2x3 = Parameter(name = 'CKM2x3',
                   nature = 'internal',
                   type = 'complex',
                   value = '0',
                   texname = '\\text{CKM2x3}')

CKM3x1 = Parameter(name = 'CKM3x1',
                   nature = 'internal',
                   type = 'complex',
                   value = '0',
                   texname = '\\text{CKM3x1}')

CKM3x2 = Parameter(name = 'CKM3x2',
                   nature = 'internal',
                   type = 'complex',
                   value = '0',
                   texname = '\\text{CKM3x2}')

CKM3x3 = Parameter(name = 'CKM3x3',
                   nature = 'internal',
                   type = 'complex',
                   value = '1',
                   texname = '\\text{CKM3x3}')

GU1x1 = Parameter(name = 'GU1x1',
                  nature = 'internal',
                  type = 'complex',
                  value = 'complex(0,1)*GUI1x1 + GUR1x1',
                  texname = '\\text{GU1x1}')

GU1x2 = Parameter(name = 'GU1x2',
                  nature = 'internal',
                  type = 'complex',
                  value = 'complex(0,1)*GUI1x2 + GUR1x2',
                  texname = '\\text{GU1x2}')

GU1x3 = Parameter(name = 'GU1x3',
                  nature = 'internal',
                  type = 'complex',
                  value = 'complex(0,1)*GUI1x3 + GUR1x3',
                  texname = '\\text{GU1x3}')

GU2x1 = Parameter(name = 'GU2x1',
                  nature = 'internal',
                  type = 'complex',
                  value = 'complex(0,1)*GUI2x1 + GUR2x1',
                  texname = '\\text{GU2x1}')

GU2x2 = Parameter(name = 'GU2x2',
                  nature = 'internal',
                  type = 'complex',
                  value = 'complex(0,1)*GUI2x2 + GUR2x2',
                  texname = '\\text{GU2x2}')

GU2x3 = Parameter(name = 'GU2x3',
                  nature = 'internal',
                  type = 'complex',
                  value = 'complex(0,1)*GUI2x3 + GUR2x3',
                  texname = '\\text{GU2x3}')

GU3x1 = Parameter(name = 'GU3x1',
                  nature = 'internal',
                  type = 'complex',
                  value = 'complex(0,1)*GUI3x1 + GUR3x1',
                  texname = '\\text{GU3x1}')

GU3x2 = Parameter(name = 'GU3x2',
                  nature = 'internal',
                  type = 'complex',
                  value = 'complex(0,1)*GUI3x2 + GUR3x2',
                  texname = '\\text{GU3x2}')

GU3x3 = Parameter(name = 'GU3x3',
                  nature = 'internal',
                  type = 'complex',
                  value = 'complex(0,1)*GUI3x3 + GUR3x3',
                  texname = '\\text{GU3x3}')

GD1x1 = Parameter(name = 'GD1x1',
                  nature = 'internal',
                  type = 'complex',
                  value = 'complex(0,1)*GDI1x1 + GDR1x1',
                  texname = '\\text{GD1x1}')

GD1x2 = Parameter(name = 'GD1x2',
                  nature = 'internal',
                  type = 'complex',
                  value = 'complex(0,1)*GDI1x2 + GDR1x2',
                  texname = '\\text{GD1x2}')

GD1x3 = Parameter(name = 'GD1x3',
                  nature = 'internal',
                  type = 'complex',
                  value = 'complex(0,1)*GDI1x3 + GDR1x3',
                  texname = '\\text{GD1x3}')

GD2x1 = Parameter(name = 'GD2x1',
                  nature = 'internal',
                  type = 'complex',
                  value = 'complex(0,1)*GDI2x1 + GDR2x1',
                  texname = '\\text{GD2x1}')

GD2x2 = Parameter(name = 'GD2x2',
                  nature = 'internal',
                  type = 'complex',
                  value = 'complex(0,1)*GDI2x2 + GDR2x2',
                  texname = '\\text{GD2x2}')

GD2x3 = Parameter(name = 'GD2x3',
                  nature = 'internal',
                  type = 'complex',
                  value = 'complex(0,1)*GDI2x3 + GDR2x3',
                  texname = '\\text{GD2x3}')

GD3x1 = Parameter(name = 'GD3x1',
                  nature = 'internal',
                  type = 'complex',
                  value = 'complex(0,1)*GDI3x1 + GDR3x1',
                  texname = '\\text{GD3x1}')

GD3x2 = Parameter(name = 'GD3x2',
                  nature = 'internal',
                  type = 'complex',
                  value = 'complex(0,1)*GDI3x2 + GDR3x2',
                  texname = '\\text{GD3x2}')

GD3x3 = Parameter(name = 'GD3x3',
                  nature = 'internal',
                  type = 'complex',
                  value = 'complex(0,1)*GDI3x3 + GDR3x3',
                  texname = '\\text{GD3x3}')

GL1x1 = Parameter(name = 'GL1x1',
                  nature = 'internal',
                  type = 'complex',
                  value = 'complex(0,1)*GLI1x1 + GLR1x1',
                  texname = '\\text{GL1x1}')

GL1x2 = Parameter(name = 'GL1x2',
                  nature = 'internal',
                  type = 'complex',
                  value = 'complex(0,1)*GLI1x2 + GLR1x2',
                  texname = '\\text{GL1x2}')

GL1x3 = Parameter(name = 'GL1x3',
                  nature = 'internal',
                  type = 'complex',
                  value = 'complex(0,1)*GLI1x3 + GLR1x3',
                  texname = '\\text{GL1x3}')

GL2x1 = Parameter(name = 'GL2x1',
                  nature = 'internal',
                  type = 'complex',
                  value = 'complex(0,1)*GLI2x1 + GLR2x1',
                  texname = '\\text{GL2x1}')

GL2x2 = Parameter(name = 'GL2x2',
                  nature = 'internal',
                  type = 'complex',
                  value = 'complex(0,1)*GLI2x2 + GLR2x2',
                  texname = '\\text{GL2x2}')

GL2x3 = Parameter(name = 'GL2x3',
                  nature = 'internal',
                  type = 'complex',
                  value = 'complex(0,1)*GLI2x3 + GLR2x3',
                  texname = '\\text{GL2x3}')

GL3x1 = Parameter(name = 'GL3x1',
                  nature = 'internal',
                  type = 'complex',
                  value = 'complex(0,1)*GLI3x1 + GLR3x1',
                  texname = '\\text{GL3x1}')

GL3x2 = Parameter(name = 'GL3x2',
                  nature = 'internal',
                  type = 'complex',
                  value = 'complex(0,1)*GLI3x2 + GLR3x2',
                  texname = '\\text{GL3x2}')

GL3x3 = Parameter(name = 'GL3x3',
                  nature = 'internal',
                  type = 'complex',
                  value = 'complex(0,1)*GLI3x3 + GLR3x3',
                  texname = '\\text{GL3x3}')

O13 = Parameter(name = 'O13',
                nature = 'internal',
                type = 'real',
                value = 'cmath.cos(a3)*cmath.sin(a2)',
                texname = '\\text{O13}')

O14 = Parameter(name = 'O14',
                nature = 'internal',
                type = 'real',
                value = 'cmath.sin(a3)',
                texname = '\\text{O14}')

O23 = Parameter(name = 'O23',
                nature = 'internal',
                type = 'real',
                value = 'cmath.cos(a2)*cmath.cos(a5)*cmath.sin(a4) - cmath.sin(a2)*cmath.sin(a3)*cmath.sin(a5)',
                texname = '\\text{O23}')

O24 = Parameter(name = 'O24',
                nature = 'internal',
                type = 'real',
                value = 'cmath.cos(a3)*cmath.sin(a5)',
                texname = '\\text{O24}')

O33 = Parameter(name = 'O33',
                nature = 'internal',
                type = 'real',
                value = 'cmath.cos(a2)*cmath.cos(a4)*cmath.cos(a6) - (cmath.cos(a5)*cmath.sin(a2)*cmath.sin(a3) + cmath.cos(a2)*cmath.sin(a4)*cmath.sin(a5))*cmath.sin(a6)',
                texname = '\\text{O33}')

O34 = Parameter(name = 'O34',
                nature = 'internal',
                type = 'real',
                value = 'cmath.cos(a3)*cmath.cos(a5)*cmath.sin(a6)',
                texname = '\\text{O34}')

O43 = Parameter(name = 'O43',
                nature = 'internal',
                type = 'real',
                value = '-(cmath.cos(a5)*cmath.cos(a6)*cmath.sin(a2)*cmath.sin(a3)) - cmath.cos(a2)*(cmath.cos(a6)*cmath.sin(a4)*cmath.sin(a5) + cmath.cos(a4)*cmath.sin(a6))',
                texname = '\\text{O43}')

O44 = Parameter(name = 'O44',
                nature = 'internal',
                type = 'real',
                value = 'cmath.cos(a3)*cmath.cos(a5)*cmath.cos(a6)',
                texname = '\\text{O44}')

rhott = Parameter(name = 'rhott',
                  nature = 'internal',
                  type = 'complex',
                  value = 'complex(0,1)*Imrhott + Rerhott',
                  texname = '\\text{rhott}')

rhobb = Parameter(name = 'rhobb',
                  nature = 'internal',
                  type = 'complex',
                  value = 'complex(0,1)*Imrhobb + Rerhobb',
                  texname = '\\text{rhobb}')

rhoee = Parameter(name = 'rhoee',
                  nature = 'internal',
                  type = 'complex',
                  value = 'complex(0,1)*Imrhoee + Rerhoee',
                  texname = '\\text{rhoee}')

MW = Parameter(name = 'MW',
               nature = 'internal',
               type = 'real',
               value = 'cmath.sqrt(MZ**2/2. + cmath.sqrt(MZ**4/4. - (aEW*cmath.pi*MZ**2)/(Gf*cmath.sqrt(2))))',
               texname = '\\text{MW}')

O11 = Parameter(name = 'O11',
                nature = 'internal',
                type = 'real',
                value = 'cmath.cos(a1)*cmath.cos(a2)*cmath.cos(a3)',
                texname = '\\text{O11}')

O12 = Parameter(name = 'O12',
                nature = 'internal',
                type = 'real',
                value = 'cmath.cos(a2)*cmath.cos(a3)*cmath.sin(a1)',
                texname = '\\text{O12}')

O21 = Parameter(name = 'O21',
                nature = 'internal',
                type = 'real',
                value = '-(cmath.cos(a4)*cmath.cos(a5)*cmath.sin(a1)) - cmath.cos(a1)*(cmath.cos(a5)*cmath.sin(a2)*cmath.sin(a4) + cmath.cos(a2)*cmath.sin(a3)*cmath.sin(a5))',
                texname = '\\text{O21}')

O22 = Parameter(name = 'O22',
                nature = 'internal',
                type = 'real',
                value = 'cmath.cos(a1)*cmath.cos(a4)*cmath.cos(a5) - cmath.sin(a1)*(cmath.cos(a5)*cmath.sin(a2)*cmath.sin(a4) + cmath.cos(a2)*cmath.sin(a3)*cmath.sin(a5))',
                texname = '\\text{O22}')

O31 = Parameter(name = 'O31',
                nature = 'internal',
                type = 'real',
                value = 'cmath.sin(a1)*(cmath.cos(a6)*cmath.sin(a4) + cmath.cos(a4)*cmath.sin(a5)*cmath.sin(a6)) - cmath.cos(a1)*(cmath.cos(a4)*cmath.cos(a6)*cmath.sin(a2) + (cmath.cos(a2)*cmath.cos(a5)*cmath.sin(a3) - cmath.sin(a2)*cmath.sin(a4)*cmath.sin(a5))*cmath.sin(a6))',
                texname = '\\text{O31}')

O32 = Parameter(name = 'O32',
                nature = 'internal',
                type = 'real',
                value = '-(cmath.cos(a1)*cmath.cos(a6)*cmath.sin(a4)) + cmath.sin(a1)*(-(cmath.cos(a2)*cmath.cos(a5)*cmath.sin(a3)) + cmath.sin(a2)*cmath.sin(a4)*cmath.sin(a5))*cmath.sin(a6) - cmath.cos(a4)*(cmath.cos(a6)*cmath.sin(a1)*cmath.sin(a2) + cmath.cos(a1)*cmath.sin(a5)*cmath.sin(a6))',
                texname = '\\text{O32}')

O41 = Parameter(name = 'O41',
                nature = 'internal',
                type = 'real',
                value = 'cmath.sin(a1)*(cmath.cos(a4)*cmath.cos(a6)*cmath.sin(a5) - cmath.sin(a4)*cmath.sin(a6)) + cmath.cos(a1)*(-(cmath.cos(a2)*cmath.cos(a5)*cmath.cos(a6)*cmath.sin(a3)) + cmath.sin(a2)*(cmath.cos(a6)*cmath.sin(a4)*cmath.sin(a5) + cmath.cos(a4)*cmath.sin(a6)))',
                texname = '\\text{O41}')

O42 = Parameter(name = 'O42',
                nature = 'internal',
                type = 'real',
                value = '-(cmath.cos(a2)*cmath.cos(a5)*cmath.cos(a6)*cmath.sin(a1)*cmath.sin(a3)) + cmath.sin(a1)*cmath.sin(a2)*(cmath.cos(a6)*cmath.sin(a4)*cmath.sin(a5) + cmath.cos(a4)*cmath.sin(a6)) + cmath.cos(a1)*(-(cmath.cos(a4)*cmath.cos(a6)*cmath.sin(a5)) + cmath.sin(a4)*cmath.sin(a6))',
                texname = '\\text{O42}')

sbeta = Parameter(name = 'sbeta',
                  nature = 'internal',
                  type = 'real',
                  value = 'cmath.sin(beta)',
                  texname = '\\text{sbeta}')

ee = Parameter(name = 'ee',
               nature = 'internal',
               type = 'real',
               value = '2*cmath.sqrt(aEW)*cmath.sqrt(cmath.pi)',
               texname = 'e')

ls = Parameter(name = 'ls',
               nature = 'internal',
               type = 'real',
               value = '(mh1**2*O14**2 + mh2**2*O24**2 + mh3**2*O34**2 + mh4**2*O44**2)/vs**2',
               texname = '\\text{ls}')

sw2 = Parameter(name = 'sw2',
                nature = 'internal',
                type = 'real',
                value = '1 - MW**2/MZ**2',
                texname = '\\text{sw2}')

cw = Parameter(name = 'cw',
               nature = 'internal',
               type = 'real',
               value = 'cmath.sqrt(1 - sw2)',
               texname = '\\text{cw}')

sw = Parameter(name = 'sw',
               nature = 'internal',
               type = 'real',
               value = 'cmath.sqrt(sw2)',
               texname = '\\text{sw}')

g1 = Parameter(name = 'g1',
               nature = 'internal',
               type = 'real',
               value = 'ee/cw',
               texname = '\\text{g1}')

gw = Parameter(name = 'gw',
               nature = 'internal',
               type = 'real',
               value = 'ee/sw',
               texname = '\\text{gw}')

vev = Parameter(name = 'vev',
                nature = 'internal',
                type = 'real',
                value = '(2.*MW*sw)/ee',
                texname = '\\text{vev}')

v = Parameter(name = 'v',
              nature = 'internal',
              type = 'real',
              value = 'vev',
              texname = 'v')

v1 = Parameter(name = 'v1',
               nature = 'internal',
               type = 'real',
               value = 'cbeta*vev',
               texname = '\\text{v1}')

v2 = Parameter(name = 'v2',
               nature = 'internal',
               type = 'real',
               value = 'sbeta*vev',
               texname = '\\text{v2}')

yb = Parameter(name = 'yb',
               nature = 'internal',
               type = 'real',
               value = '(ymb*cmath.sqrt(2))/vev',
               texname = '\\text{yb}')

yc = Parameter(name = 'yc',
               nature = 'internal',
               type = 'real',
               value = '(ymc*cmath.sqrt(2))/vev',
               texname = '\\text{yc}')

ydo = Parameter(name = 'ydo',
                nature = 'internal',
                type = 'real',
                value = '(ymdo*cmath.sqrt(2))/vev',
                texname = '\\text{ydo}')

ye = Parameter(name = 'ye',
               nature = 'internal',
               type = 'real',
               value = '(yme*cmath.sqrt(2))/vev',
               texname = '\\text{ye}')

ym = Parameter(name = 'ym',
               nature = 'internal',
               type = 'real',
               value = '(ymm*cmath.sqrt(2))/vev',
               texname = '\\text{ym}')

ys = Parameter(name = 'ys',
               nature = 'internal',
               type = 'real',
               value = '(yms*cmath.sqrt(2))/vev',
               texname = '\\text{ys}')

yt = Parameter(name = 'yt',
               nature = 'internal',
               type = 'real',
               value = '(ymt*cmath.sqrt(2))/vev',
               texname = '\\text{yt}')

ytau = Parameter(name = 'ytau',
                 nature = 'internal',
                 type = 'real',
                 value = '(ymtau*cmath.sqrt(2))/vev',
                 texname = '\\text{ytau}')

yup = Parameter(name = 'yup',
                nature = 'internal',
                type = 'real',
                value = '(ymup*cmath.sqrt(2))/vev',
                texname = '\\text{yup}')

etaD11x1 = Parameter(name = 'etaD11x1',
                     nature = 'internal',
                     type = 'real',
                     value = '(v1*ymdo*cmath.sqrt(2))/vev',
                     texname = '\\text{etaD11x1}')

etaD12x2 = Parameter(name = 'etaD12x2',
                     nature = 'internal',
                     type = 'real',
                     value = '(v1*yms*cmath.sqrt(2))/vev',
                     texname = '\\text{etaD12x2}')

etaD13x3 = Parameter(name = 'etaD13x3',
                     nature = 'internal',
                     type = 'complex',
                     value = '-((rhobb*v2)/vev) + (v1*ymb*cmath.sqrt(2))/vev',
                     texname = '\\text{etaD13x3}')

etaD21x1 = Parameter(name = 'etaD21x1',
                     nature = 'internal',
                     type = 'real',
                     value = '(v2*ymdo*cmath.sqrt(2))/vev',
                     texname = '\\text{etaD21x1}')

etaD22x2 = Parameter(name = 'etaD22x2',
                     nature = 'internal',
                     type = 'real',
                     value = '(v2*yms*cmath.sqrt(2))/vev',
                     texname = '\\text{etaD22x2}')

etaD23x3 = Parameter(name = 'etaD23x3',
                     nature = 'internal',
                     type = 'complex',
                     value = '(rhobb*v1)/vev + (v2*ymb*cmath.sqrt(2))/vev',
                     texname = '\\text{etaD23x3}')

etaL11x1 = Parameter(name = 'etaL11x1',
                     nature = 'internal',
                     type = 'complex',
                     value = '-((rhoee*v2)/vev) + (v1*yme*cmath.sqrt(2))/vev',
                     texname = '\\text{etaL11x1}')

etaL12x2 = Parameter(name = 'etaL12x2',
                     nature = 'internal',
                     type = 'real',
                     value = '(v1*ymm*cmath.sqrt(2))/vev',
                     texname = '\\text{etaL12x2}')

etaL13x3 = Parameter(name = 'etaL13x3',
                     nature = 'internal',
                     type = 'real',
                     value = '(v1*ymtau*cmath.sqrt(2))/vev',
                     texname = '\\text{etaL13x3}')

etaL21x1 = Parameter(name = 'etaL21x1',
                     nature = 'internal',
                     type = 'complex',
                     value = '(rhoee*v1)/vev + (v2*yme*cmath.sqrt(2))/vev',
                     texname = '\\text{etaL21x1}')

etaL22x2 = Parameter(name = 'etaL22x2',
                     nature = 'internal',
                     type = 'real',
                     value = '(v2*ymm*cmath.sqrt(2))/vev',
                     texname = '\\text{etaL22x2}')

etaL23x3 = Parameter(name = 'etaL23x3',
                     nature = 'internal',
                     type = 'real',
                     value = '(v2*ymtau*cmath.sqrt(2))/vev',
                     texname = '\\text{etaL23x3}')

etaU11x1 = Parameter(name = 'etaU11x1',
                     nature = 'internal',
                     type = 'real',
                     value = '(v1*ymup*cmath.sqrt(2))/vev',
                     texname = '\\text{etaU11x1}')

etaU12x2 = Parameter(name = 'etaU12x2',
                     nature = 'internal',
                     type = 'real',
                     value = '(v1*ymc*cmath.sqrt(2))/vev',
                     texname = '\\text{etaU12x2}')

etaU13x3 = Parameter(name = 'etaU13x3',
                     nature = 'internal',
                     type = 'complex',
                     value = '-((rhott*v2)/v) + (v1*ymt*cmath.sqrt(2))/vev',
                     texname = '\\text{etaU13x3}')

etaU21x1 = Parameter(name = 'etaU21x1',
                     nature = 'internal',
                     type = 'real',
                     value = '(v2*ymup*cmath.sqrt(2))/vev',
                     texname = '\\text{etaU21x1}')

etaU22x2 = Parameter(name = 'etaU22x2',
                     nature = 'internal',
                     type = 'real',
                     value = '(v2*ymc*cmath.sqrt(2))/vev',
                     texname = '\\text{etaU22x2}')

etaU23x3 = Parameter(name = 'etaU23x3',
                     nature = 'internal',
                     type = 'complex',
                     value = '(rhott*v1)/v + (v2*ymt*cmath.sqrt(2))/vev',
                     texname = '\\text{etaU23x3}')

k3I = Parameter(name = 'k3I',
                nature = 'internal',
                type = 'real',
                value = '(-2*(mh1**2*O13*O14 + mh2**2*O23*O24 + mh3**2*O33*O34 + mh4**2*O43*O44))/(v*vs)',
                texname = '\\text{k3I}')

ka1 = Parameter(name = 'ka1',
                nature = 'internal',
                type = 'real',
                value = '(2*(mh1**2*O11*O14 + mh2**2*O21*O24 + mh3**2*O31*O34 + mh4**2*O41*O44) - k3R*v2*vs)/(2.*v1*vs)',
                texname = '\\text{ka1}')

ka2 = Parameter(name = 'ka2',
                nature = 'internal',
                type = 'real',
                value = '(2*(mh1**2*O12*O14 + mh2**2*O22*O24 + mh3**2*O32*O34 + mh4**2*O42*O44) - k3R*v1*vs)/(2.*v2*vs)',
                texname = '\\text{ka2}')

l1 = Parameter(name = 'l1',
               nature = 'internal',
               type = 'real',
               value = '(4*mh1**2*O11**2*v1 + 4*mh2**2*O21**2*v1 + 4*mh3**2*O31**2*v1 + 4*mh4**2*O41**2*v1 - 2*m12R*v2 - 3*l6R*v1**2*v2 + l7R*v2**3 + k3R*v2*vs**2)/(4.*v1**3)',
               texname = '\\text{l1}')

l2 = Parameter(name = 'l2',
               nature = 'internal',
               type = 'real',
               value = '(-2*m12R*v1 + l6R*v1**3 + v2*(4*(mh1**2*O12**2 + mh2**2*O22**2 + mh3**2*O32**2 + mh4**2*O42**2) - 3*l7R*v1*v2) + k3R*v1*vs**2)/(4.*v2**3)',
               texname = '\\text{l2}')

l3 = Parameter(name = 'l3',
               nature = 'internal',
               type = 'real',
               value = '(-2*m12R*v**2 + 4*mh1**2*O11*O12*v**2 + 4*mh2**2*O21*O22*v**2 + 4*mh3**2*O31*O32*v**2 + 4*mh4**2*O41*O42*v**2 - l6R*v**2*v1**2 - 8*mhc**2*v1*v2 - l7R*v**2*v2**2 + k3R*v**2*vs**2)/(4.*v**2*v1*v2)',
               texname = '\\text{l3}')

l4 = Parameter(name = 'l4',
               nature = 'internal',
               type = 'real',
               value = '(2*m12R*v**2 - l6R*v**2*v1**2 + v2*(4*(2*mhc**2 + mh1**2*O13**2 + mh2**2*O23**2 + mh3**2*O33**2 + mh4**2*O43**2)*v1 - l7R*v**2*v2) - k3R*v**2*vs**2)/(4.*v**2*v1*v2)',
               texname = '\\text{l4}')

l5R = Parameter(name = 'l5R',
                nature = 'internal',
                type = 'real',
                value = '(2*m12R*v**2 - l6R*v**2*v1**2 + v2*(-4*(mh1**2*O13**2 + mh2**2*O23**2 + mh3**2*O33**2 + mh4**2*O43**2)*v1 - l7R*v**2*v2) - k3R*v**2*vs**2)/(4.*v**2*v1*v2)',
                texname = '\\text{l5R}')

l6I = Parameter(name = 'l6I',
                nature = 'internal',
                type = 'complex',
                value = '-((2*(mh1**2*O11*O13 + mh2**2*O21*O23 + mh3**2*O31*O33 + mh4**2*O41*O43) + l5I*v*v2)/(v*v1))',
                texname = '\\text{l6I}')

l7I = Parameter(name = 'l7I',
                nature = 'internal',
                type = 'real',
                value = '-((2*(mh1**2*O12*O13 + mh2**2*O22*O23 + mh3**2*O32*O33 + mh4**2*O42*O43) + l5I*v*v1)/(v*v2))',
                texname = '\\text{l7I}')

m11 = Parameter(name = 'm11',
                nature = 'internal',
                type = 'real',
                value = 'l1*v1**2 - (m12R*v2)/v1 + (3*l6R*v1*v2)/2. + l3*v2**2 + l4*v2**2 + l5R*v2**2 + (l7R*v2**3)/(2.*v1) + ka1*vs**2 + (k3R*v2*vs**2)/(2.*v1)',
                texname = '\\text{m11}')

m12I = Parameter(name = 'm12I',
                 nature = 'internal',
                 type = 'real',
                 value = '(l6I*v1**2 + 2*l5I*v1*v2 + l7I*v2**2 + k3I*vs**2)/2.',
                 texname = '\\text{m12I}')

m22 = Parameter(name = 'm22',
                nature = 'internal',
                type = 'real',
                value = 'l3*v1**2 + l4*v1**2 + l5R*v1**2 - (m12R*v1)/v2 + (l6R*v1**3)/(2.*v2) + (3*l7R*v1*v2)/2. + l2*v2**2 + ka2*vs**2 + (k3R*v1*vs**2)/(2.*v2)',
                texname = '\\text{m22}')

mus = Parameter(name = 'mus',
                nature = 'internal',
                type = 'real',
                value = '(4*mud + ka1*v1**2 + k3R*v1*v2 + ka2*v2**2 + ls*vs**2)/2.',
                texname = '\\text{mus}')

ka3 = Parameter(name = 'ka3',
                nature = 'internal',
                type = 'complex',
                value = 'complex(0,1)*k3I + k3R',
                texname = '\\text{ka3}')

l5 = Parameter(name = 'l5',
               nature = 'internal',
               type = 'complex',
               value = 'complex(0,1)*l5I + l5R',
               texname = '\\text{l5}')

l6 = Parameter(name = 'l6',
               nature = 'internal',
               type = 'complex',
               value = 'complex(0,1)*l6I + l6R',
               texname = '\\text{l6}')

l7 = Parameter(name = 'l7',
               nature = 'internal',
               type = 'complex',
               value = 'complex(0,1)*l7I + l7R',
               texname = '\\text{l7}')

m12 = Parameter(name = 'm12',
                nature = 'internal',
                type = 'complex',
                value = 'complex(0,1)*m12I + m12R',
                texname = '\\text{m12}')

I1a11 = Parameter(name = 'I1a11',
                  nature = 'internal',
                  type = 'complex',
                  value = 'CKM1x1*etaU11x1',
                  texname = '\\text{I1a11}')

I1a12 = Parameter(name = 'I1a12',
                  nature = 'internal',
                  type = 'complex',
                  value = 'CKM1x2*etaU11x1',
                  texname = '\\text{I1a12}')

I1a13 = Parameter(name = 'I1a13',
                  nature = 'internal',
                  type = 'complex',
                  value = 'CKM1x3*etaU11x1',
                  texname = '\\text{I1a13}')

I1a21 = Parameter(name = 'I1a21',
                  nature = 'internal',
                  type = 'complex',
                  value = 'CKM2x1*etaU12x2',
                  texname = '\\text{I1a21}')

I1a22 = Parameter(name = 'I1a22',
                  nature = 'internal',
                  type = 'complex',
                  value = 'CKM2x2*etaU12x2',
                  texname = '\\text{I1a22}')

I1a23 = Parameter(name = 'I1a23',
                  nature = 'internal',
                  type = 'complex',
                  value = 'CKM2x3*etaU12x2',
                  texname = '\\text{I1a23}')

I1a31 = Parameter(name = 'I1a31',
                  nature = 'internal',
                  type = 'complex',
                  value = 'CKM3x1*etaU13x3',
                  texname = '\\text{I1a31}')

I1a32 = Parameter(name = 'I1a32',
                  nature = 'internal',
                  type = 'complex',
                  value = 'CKM3x2*etaU13x3',
                  texname = '\\text{I1a32}')

I1a33 = Parameter(name = 'I1a33',
                  nature = 'internal',
                  type = 'complex',
                  value = 'CKM3x3*etaU13x3',
                  texname = '\\text{I1a33}')

I2a11 = Parameter(name = 'I2a11',
                  nature = 'internal',
                  type = 'complex',
                  value = 'CKM1x1*etaU21x1',
                  texname = '\\text{I2a11}')

I2a12 = Parameter(name = 'I2a12',
                  nature = 'internal',
                  type = 'complex',
                  value = 'CKM1x2*etaU21x1',
                  texname = '\\text{I2a12}')

I2a13 = Parameter(name = 'I2a13',
                  nature = 'internal',
                  type = 'complex',
                  value = 'CKM1x3*etaU21x1',
                  texname = '\\text{I2a13}')

I2a21 = Parameter(name = 'I2a21',
                  nature = 'internal',
                  type = 'complex',
                  value = 'CKM2x1*etaU22x2',
                  texname = '\\text{I2a21}')

I2a22 = Parameter(name = 'I2a22',
                  nature = 'internal',
                  type = 'complex',
                  value = 'CKM2x2*etaU22x2',
                  texname = '\\text{I2a22}')

I2a23 = Parameter(name = 'I2a23',
                  nature = 'internal',
                  type = 'complex',
                  value = 'CKM2x3*etaU22x2',
                  texname = '\\text{I2a23}')

I2a31 = Parameter(name = 'I2a31',
                  nature = 'internal',
                  type = 'complex',
                  value = 'CKM3x1*etaU23x3',
                  texname = '\\text{I2a31}')

I2a32 = Parameter(name = 'I2a32',
                  nature = 'internal',
                  type = 'complex',
                  value = 'CKM3x2*etaU23x3',
                  texname = '\\text{I2a32}')

I2a33 = Parameter(name = 'I2a33',
                  nature = 'internal',
                  type = 'complex',
                  value = 'CKM3x3*etaU23x3',
                  texname = '\\text{I2a33}')

I3a11 = Parameter(name = 'I3a11',
                  nature = 'internal',
                  type = 'complex',
                  value = 'CKM1x1*etaD11x1',
                  texname = '\\text{I3a11}')

I3a12 = Parameter(name = 'I3a12',
                  nature = 'internal',
                  type = 'complex',
                  value = 'CKM1x2*etaD12x2',
                  texname = '\\text{I3a12}')

I3a13 = Parameter(name = 'I3a13',
                  nature = 'internal',
                  type = 'complex',
                  value = 'CKM1x3*etaD13x3',
                  texname = '\\text{I3a13}')

I3a21 = Parameter(name = 'I3a21',
                  nature = 'internal',
                  type = 'complex',
                  value = 'CKM2x1*etaD11x1',
                  texname = '\\text{I3a21}')

I3a22 = Parameter(name = 'I3a22',
                  nature = 'internal',
                  type = 'complex',
                  value = 'CKM2x2*etaD12x2',
                  texname = '\\text{I3a22}')

I3a23 = Parameter(name = 'I3a23',
                  nature = 'internal',
                  type = 'complex',
                  value = 'CKM2x3*etaD13x3',
                  texname = '\\text{I3a23}')

I3a31 = Parameter(name = 'I3a31',
                  nature = 'internal',
                  type = 'complex',
                  value = 'CKM3x1*etaD11x1',
                  texname = '\\text{I3a31}')

I3a32 = Parameter(name = 'I3a32',
                  nature = 'internal',
                  type = 'complex',
                  value = 'CKM3x2*etaD12x2',
                  texname = '\\text{I3a32}')

I3a33 = Parameter(name = 'I3a33',
                  nature = 'internal',
                  type = 'complex',
                  value = 'CKM3x3*etaD13x3',
                  texname = '\\text{I3a33}')

I4a11 = Parameter(name = 'I4a11',
                  nature = 'internal',
                  type = 'complex',
                  value = 'CKM1x1*etaD21x1',
                  texname = '\\text{I4a11}')

I4a12 = Parameter(name = 'I4a12',
                  nature = 'internal',
                  type = 'complex',
                  value = 'CKM1x2*etaD22x2',
                  texname = '\\text{I4a12}')

I4a13 = Parameter(name = 'I4a13',
                  nature = 'internal',
                  type = 'complex',
                  value = 'CKM1x3*etaD23x3',
                  texname = '\\text{I4a13}')

I4a21 = Parameter(name = 'I4a21',
                  nature = 'internal',
                  type = 'complex',
                  value = 'CKM2x1*etaD21x1',
                  texname = '\\text{I4a21}')

I4a22 = Parameter(name = 'I4a22',
                  nature = 'internal',
                  type = 'complex',
                  value = 'CKM2x2*etaD22x2',
                  texname = '\\text{I4a22}')

I4a23 = Parameter(name = 'I4a23',
                  nature = 'internal',
                  type = 'complex',
                  value = 'CKM2x3*etaD23x3',
                  texname = '\\text{I4a23}')

I4a31 = Parameter(name = 'I4a31',
                  nature = 'internal',
                  type = 'complex',
                  value = 'CKM3x1*etaD21x1',
                  texname = '\\text{I4a31}')

I4a32 = Parameter(name = 'I4a32',
                  nature = 'internal',
                  type = 'complex',
                  value = 'CKM3x2*etaD22x2',
                  texname = '\\text{I4a32}')

I4a33 = Parameter(name = 'I4a33',
                  nature = 'internal',
                  type = 'complex',
                  value = 'CKM3x3*etaD23x3',
                  texname = '\\text{I4a33}')

I5a11 = Parameter(name = 'I5a11',
                  nature = 'internal',
                  type = 'complex',
                  value = 'etaD11x1*complexconjugate(CKM1x1)',
                  texname = '\\text{I5a11}')

I5a12 = Parameter(name = 'I5a12',
                  nature = 'internal',
                  type = 'complex',
                  value = 'etaD11x1*complexconjugate(CKM2x1)',
                  texname = '\\text{I5a12}')

I5a13 = Parameter(name = 'I5a13',
                  nature = 'internal',
                  type = 'complex',
                  value = 'etaD11x1*complexconjugate(CKM3x1)',
                  texname = '\\text{I5a13}')

I5a21 = Parameter(name = 'I5a21',
                  nature = 'internal',
                  type = 'complex',
                  value = 'etaD12x2*complexconjugate(CKM1x2)',
                  texname = '\\text{I5a21}')

I5a22 = Parameter(name = 'I5a22',
                  nature = 'internal',
                  type = 'complex',
                  value = 'etaD12x2*complexconjugate(CKM2x2)',
                  texname = '\\text{I5a22}')

I5a23 = Parameter(name = 'I5a23',
                  nature = 'internal',
                  type = 'complex',
                  value = 'etaD12x2*complexconjugate(CKM3x2)',
                  texname = '\\text{I5a23}')

I5a31 = Parameter(name = 'I5a31',
                  nature = 'internal',
                  type = 'complex',
                  value = 'etaD13x3*complexconjugate(CKM1x3)',
                  texname = '\\text{I5a31}')

I5a32 = Parameter(name = 'I5a32',
                  nature = 'internal',
                  type = 'complex',
                  value = 'etaD13x3*complexconjugate(CKM2x3)',
                  texname = '\\text{I5a32}')

I5a33 = Parameter(name = 'I5a33',
                  nature = 'internal',
                  type = 'complex',
                  value = 'etaD13x3*complexconjugate(CKM3x3)',
                  texname = '\\text{I5a33}')

I6a11 = Parameter(name = 'I6a11',
                  nature = 'internal',
                  type = 'complex',
                  value = 'etaD21x1*complexconjugate(CKM1x1)',
                  texname = '\\text{I6a11}')

I6a12 = Parameter(name = 'I6a12',
                  nature = 'internal',
                  type = 'complex',
                  value = 'etaD21x1*complexconjugate(CKM2x1)',
                  texname = '\\text{I6a12}')

I6a13 = Parameter(name = 'I6a13',
                  nature = 'internal',
                  type = 'complex',
                  value = 'etaD21x1*complexconjugate(CKM3x1)',
                  texname = '\\text{I6a13}')

I6a21 = Parameter(name = 'I6a21',
                  nature = 'internal',
                  type = 'complex',
                  value = 'etaD22x2*complexconjugate(CKM1x2)',
                  texname = '\\text{I6a21}')

I6a22 = Parameter(name = 'I6a22',
                  nature = 'internal',
                  type = 'complex',
                  value = 'etaD22x2*complexconjugate(CKM2x2)',
                  texname = '\\text{I6a22}')

I6a23 = Parameter(name = 'I6a23',
                  nature = 'internal',
                  type = 'complex',
                  value = 'etaD22x2*complexconjugate(CKM3x2)',
                  texname = '\\text{I6a23}')

I6a31 = Parameter(name = 'I6a31',
                  nature = 'internal',
                  type = 'complex',
                  value = 'etaD23x3*complexconjugate(CKM1x3)',
                  texname = '\\text{I6a31}')

I6a32 = Parameter(name = 'I6a32',
                  nature = 'internal',
                  type = 'complex',
                  value = 'etaD23x3*complexconjugate(CKM2x3)',
                  texname = '\\text{I6a32}')

I6a33 = Parameter(name = 'I6a33',
                  nature = 'internal',
                  type = 'complex',
                  value = 'etaD23x3*complexconjugate(CKM3x3)',
                  texname = '\\text{I6a33}')

I7a11 = Parameter(name = 'I7a11',
                  nature = 'internal',
                  type = 'complex',
                  value = 'etaU11x1*complexconjugate(CKM1x1)',
                  texname = '\\text{I7a11}')

I7a12 = Parameter(name = 'I7a12',
                  nature = 'internal',
                  type = 'complex',
                  value = 'etaU12x2*complexconjugate(CKM2x1)',
                  texname = '\\text{I7a12}')

I7a13 = Parameter(name = 'I7a13',
                  nature = 'internal',
                  type = 'complex',
                  value = 'etaU13x3*complexconjugate(CKM3x1)',
                  texname = '\\text{I7a13}')

I7a21 = Parameter(name = 'I7a21',
                  nature = 'internal',
                  type = 'complex',
                  value = 'etaU11x1*complexconjugate(CKM1x2)',
                  texname = '\\text{I7a21}')

I7a22 = Parameter(name = 'I7a22',
                  nature = 'internal',
                  type = 'complex',
                  value = 'etaU12x2*complexconjugate(CKM2x2)',
                  texname = '\\text{I7a22}')

I7a23 = Parameter(name = 'I7a23',
                  nature = 'internal',
                  type = 'complex',
                  value = 'etaU13x3*complexconjugate(CKM3x2)',
                  texname = '\\text{I7a23}')

I7a31 = Parameter(name = 'I7a31',
                  nature = 'internal',
                  type = 'complex',
                  value = 'etaU11x1*complexconjugate(CKM1x3)',
                  texname = '\\text{I7a31}')

I7a32 = Parameter(name = 'I7a32',
                  nature = 'internal',
                  type = 'complex',
                  value = 'etaU12x2*complexconjugate(CKM2x3)',
                  texname = '\\text{I7a32}')

I7a33 = Parameter(name = 'I7a33',
                  nature = 'internal',
                  type = 'complex',
                  value = 'etaU13x3*complexconjugate(CKM3x3)',
                  texname = '\\text{I7a33}')

I8a11 = Parameter(name = 'I8a11',
                  nature = 'internal',
                  type = 'complex',
                  value = 'etaU21x1*complexconjugate(CKM1x1)',
                  texname = '\\text{I8a11}')

I8a12 = Parameter(name = 'I8a12',
                  nature = 'internal',
                  type = 'complex',
                  value = 'etaU22x2*complexconjugate(CKM2x1)',
                  texname = '\\text{I8a12}')

I8a13 = Parameter(name = 'I8a13',
                  nature = 'internal',
                  type = 'complex',
                  value = 'etaU23x3*complexconjugate(CKM3x1)',
                  texname = '\\text{I8a13}')

I8a21 = Parameter(name = 'I8a21',
                  nature = 'internal',
                  type = 'complex',
                  value = 'etaU21x1*complexconjugate(CKM1x2)',
                  texname = '\\text{I8a21}')

I8a22 = Parameter(name = 'I8a22',
                  nature = 'internal',
                  type = 'complex',
                  value = 'etaU22x2*complexconjugate(CKM2x2)',
                  texname = '\\text{I8a22}')

I8a23 = Parameter(name = 'I8a23',
                  nature = 'internal',
                  type = 'complex',
                  value = 'etaU23x3*complexconjugate(CKM3x2)',
                  texname = '\\text{I8a23}')

I8a31 = Parameter(name = 'I8a31',
                  nature = 'internal',
                  type = 'complex',
                  value = 'etaU21x1*complexconjugate(CKM1x3)',
                  texname = '\\text{I8a31}')

I8a32 = Parameter(name = 'I8a32',
                  nature = 'internal',
                  type = 'complex',
                  value = 'etaU22x2*complexconjugate(CKM2x3)',
                  texname = '\\text{I8a32}')

I8a33 = Parameter(name = 'I8a33',
                  nature = 'internal',
                  type = 'complex',
                  value = 'etaU23x3*complexconjugate(CKM3x3)',
                  texname = '\\text{I8a33}')
